<?php
echo "
<link rel='stylesheet' href='../common_files/style.css' />
";
?>